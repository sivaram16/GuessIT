# Guessit

This is a fun little number guessing name where the goal is to guess the number that the CPU has in mind within a limited number of guesses this Flutter app was developed and submitted for the Flutter Create Contest.

## Screenshots

<img src="./assets/images/snap2.png" width="300" />
<img src="./assets/images/snap.png" width="300" /> 
<img src="./assets/images/snap1.png" width="300" />



