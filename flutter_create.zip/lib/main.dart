import 'package:flutter/material.dart';
import 'welcome.dart';

void main() => runApp(MaterialApp(
  theme: ThemeData(fontFamily: 'Montserrat'),
      home: Welcome(),
    ));
